# PyMuPDF 1.23.7

This wheel contains MuPDF shared libraries for use by PyMuPDF.

This wheel is shared by PyMuPDF wheels that are spcific to different Python
versions, significantly reducing the total size of a release.
